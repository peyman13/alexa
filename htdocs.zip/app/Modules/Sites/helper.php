<?php
 /**
 *	Sites Helper  
 */