<?php namespace App\Modules\Sites\Models;

use Illuminate\Database\Eloquent\Model;

class Sites extends Model {

	//

}
