<?php 

return [
    'welcome' => 'Welcome, this is Sites module.'
];
