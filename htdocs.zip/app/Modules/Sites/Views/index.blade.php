<?php

echo trans('Sites::example.welcome');