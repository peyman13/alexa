<?php
 /**
 *	Office Helper  
 */