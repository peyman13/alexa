<?php namespace App\Modules\Office\Models;

use Illuminate\Database\Eloquent\Model;

class Office extends Model {

	//

}
