<?php

echo trans('office::example.welcome');