<?php 

return [
    'welcome' => 'Welcome, this is Office module.'
];
